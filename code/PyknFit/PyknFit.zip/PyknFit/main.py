import tkinter as tk
from app import PyknFitApp
import traceback

if __name__ == "__main__":
    try:
        root = tk.Tk()
        app = PyknFitApp(root)
        root.mainloop()

    except Exception as e:
        print("Une erreur est survenue :")
        traceback.print_exc()

    input("\nAppuie sur Entrée pour fermer...")